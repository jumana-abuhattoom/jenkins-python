# Jenkins-Python
<img width="675" alt="image" src="https://user-images.githubusercontent.com/57872327/175812793-4f53fdb9-d5bd-407a-8c4c-3b30c353baaf.png"> 
